-- BRAINGLOBE ATLAS --
Generated on: 06/07/2022

------------------------------


    name:   salk_cord
    citation:   unpublished
    atlas_link:   
    species:   Mus musculus
    symmetric:   True
    resolution:   (10.0, 10.0, 10.0)
    orientation:   asr
    version:   1.0
    shape:   (790, 140, 225)
    trasform_to_bg:   ((1.0, 0.0, 0.0, 0.0), (0.0, 1.0, 0.0, 0.0), (0.0, 0.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0))
    additional_references:   []
    atlas_packager:   MetaCell LLC, Ltd.



------------------------------





-- BRAIN STRUCTURES TREE --
root (1)
├── GM (3)
│   ├── 1Sp (4)
│   ├── 2Sp (5)
│   ├── 3Sp (6)
│   ├── 4Sp (7)
│   ├── 5Sp (8)
│   ├── 6Sp (9)
│   ├── 7Sp (10)
│   ├── 8Sp (11)
│   ├── 9Sp (12)
│   └── CC (13)
└── WM (2)
