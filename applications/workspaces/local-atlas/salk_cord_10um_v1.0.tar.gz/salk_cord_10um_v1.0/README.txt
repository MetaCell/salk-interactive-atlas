-- BRAINGLOBE ATLAS --
Generated on: 17/11/2021

------------------------------


    name:   salk_cord
    citation:   unpublished
    atlas_link:   
    species:   Mus musculus
    symmetric:   True
    resolution:   (10.0, 10.0, 10.0)
    orientation:   asr
    version:   1.0
    shape:   (769, 145, 243)
    trasform_to_bg:   ((1.0, 0.0, 0.0, 0.0), (0.0, 1.0, 0.0, 0.0), (0.0, 0.0, 1.0, 0.0), (0.0, 0.0, 0.0, 1.0))
    additional_references:   []
    atlas_packager:   MetaCell LLC, Ltd.



------------------------------





-- BRAIN STRUCTURES TREE --
root (1)
├── GM (2)
└── WM (3)
